package com.example.a1_fakenews

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
