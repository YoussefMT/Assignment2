# a1_fakenews

CS 3130 Assignment 1 

Fake News (Reader)

Generate fake news using the faker_dart package

## Getting Started

Run the app and see the news stories

Click any story to read it 